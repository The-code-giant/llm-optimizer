ALTER TABLE "tracker_data" ALTER COLUMN "session_id" SET DATA TYPE varchar(255);--> statement-breakpoint
ALTER TABLE "tracker_data" ALTER COLUMN "anonymous_user_id" SET DATA TYPE varchar(255);